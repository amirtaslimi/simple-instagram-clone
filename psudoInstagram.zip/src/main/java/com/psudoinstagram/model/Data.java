package com.psudoinstagram.model;

import java.util.ArrayList;

public class Data {
    public static ArrayList<User>allUsers = new ArrayList<>();
    public static ArrayList<Post>HomePost = new ArrayList<>();
}
