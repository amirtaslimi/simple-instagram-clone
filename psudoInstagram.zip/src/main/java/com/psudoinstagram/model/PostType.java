package com.psudoinstagram.model;

public enum PostType {
    PHOTO,
    VIDEO,
    TEXT
}
